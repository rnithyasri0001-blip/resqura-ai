# RESQURA AI – Backend (Node 22, zero dependencies, SQLite)

## Run
```
cd backend
cp .env.example .env        # optional for dev; AUTH_SECRET is REQUIRED when NODE_ENV=production
node --no-warnings server.js
```
Open http://localhost:8080 – the server also serves the existing `index.html`, so the frontend and API share one origin.
Open the same URL on two phones/browsers (one Rescue, one Help & Services) and requests travel through the server.
If `index.html` is opened as a plain file (no server) it keeps working in the old prototype mode.
Tests: `node --no-warnings tests/api.test.js` (62 checks).

## What exists (real, tested)
- Auth/sessions (random token, only its SHA-256 stored, expiry, logout), roles, rate limiting, security headers.
- Location: GPS **or** manual place/district/PIN; stored per user and per request.
- Help / Services / Emergency requests – separate kinds, idempotent ids (retry never duplicates), status history in DB.
- Status flow Pending → Accepted → In Progress → Completed, plus Cancelled (owner), Rejected (per-team decline), Expired (auto after `REQUEST_EXPIRE_HOURS`).
- Rescue list sorted by real distance (haversine); `nearby` flag from `NEARBY_KM` → green card + "NEARBY · x km". No coordinates = no invented distance, listed after known ones.
- Privacy: requester sees only own data; Rescue sees pending requests, phone is masked on Help/Services until that team accepts; after acceptance only the assigned team keeps access; other teams lose it.
- Media: images (JPEG/PNG/WebP, magic-byte checked) and video (MP4/WebM, raw upload) saved as files, DB holds references, size/count limits, short-lived HMAC-signed URLs.
- Real-time: Server-Sent Events with one-time tickets (no token in URL); client reconnects and also polls every 20 s.
- Notifications: stored history, de-duplicated, critical (emergency/official alerts) always on, non-critical can be muted via `PATCH /api/me {prefs:{nonCritical:false}}`.
- Disaster monitor: USGS earthquake feed + any RSS/CAP feeds you configure (`EXTRA_ALERT_FEEDS`), levels official / trusted / unverified (unverified is never pushed), dedupe, expiry, "ended/cancelled" updates, per-source health + log, only users inside the affected radius/area are notified.
- Team connect API: team ID, request, approve, duplicate/self block, notification.

## Not done / limits – please read
1. **Login has no OTP/password.** Name + mobile only (as in your UI). Anyone who knows a number can sign in as it. Before real use add SMS OTP (needs a provider key, e.g. MSG91/Twilio). Not implemented, so no key is asked yet.
2. **Push notifications are not wired.** In-app list, live SSE and browser notifications (when permission is granted) work. Mobile push needs FCM/APNs or web-push + VAPID keys – switch `PUSH_ENABLED` exists but does nothing yet. The app never claims push delivery.
3. **Live USGS fetch was not tested here** (sandbox has no internet). Parser + dispatch were tested with a local feed in USGS format. National agency feeds (IMD/NDMA/CAP) are yours to add in `EXTRA_ALERT_FEEDS`; verify each source's terms.
4. Connect screen: backend API is ready, but your Connect UI has no Team-ID field, so it is not wired (no redesign made). Bluetooth stays browser Web Bluetooth (Chrome/Android only, not iOS Safari) and exchanges no personal data.
5. Phone browsers need **HTTPS** for GPS/camera – host behind TLS. Media is on disk (not encrypted at rest), mobile numbers plain in SQLite: use disk encryption/backup rules.
6. Video chosen in the form is uploaded from memory; if the page is closed before the upload finishes it must be re-attached. Images are downscaled in the app before upload.
7. Single-node SQLite; fine for pilot, move to Postgres + object storage + Redis for scale.

## Keys you may need
| Purpose | Variable | Where |
|---|---|---|
| Production signing secret | `AUTH_SECRET` | `openssl rand -hex 32` |
| Extra alert feeds | `EXTRA_ALERT_FEEDS` | agency RSS/CAP URL (some need registration) |
| Mobile push (future) | `VAPID_*` / FCM | Google/Firebase |
| SMS OTP (future) | provider key | MSG91 / Twilio |
