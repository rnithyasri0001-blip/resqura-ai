'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const cfg = require('./config'), db = require('./db');
const now = () => Date.now(), rid = (p) => p + crypto.randomBytes(8).toString('hex');
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const hmac = s => crypto.createHmac('sha256', cfg.secret).update(s).digest('hex');
const q = (sql, ...a) => db.prepare(sql);
const get = (sql, ...a) => db.prepare(sql).get(...a), all = (sql, ...a) => db.prepare(sql).all(...a), run = (sql, ...a) => db.prepare(sql).run(...a);
fs.mkdirSync(cfg.mediaDir, { recursive: true, mode: 0o700 });

/* ---------- helpers ---------- */
class HttpErr extends Error { constructor(s, m) { super(m); this.status = s; } }
const bad = (m) => new HttpErr(400, m), forbid = (m = 'Not allowed') => new HttpErr(403, m), nf = (m = 'Not found') => new HttpErr(404, m);
const hav = (a, b, c, d) => { const R = 6371, r = x => x * Math.PI / 180, dl = r(c - a), dn = r(d - b), h = Math.sin(dl / 2) ** 2 + Math.cos(r(a)) * Math.cos(r(c)) * Math.sin(dn / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };
const num0 = v => v !== null && v !== undefined && v !== '' && Number.isFinite(+v);
const validLoc = (l) => l && typeof l === 'object' && num0(l.lat) && num0(l.lon) && Math.abs(+l.lat) <= 90 && Math.abs(+l.lon) <= 180;
const clip = (s, n) => (typeof s === 'string' ? s.trim().slice(0, n) : '');
const maskPhone = p => String(p).replace(/^(\+?\d{0,3}\s?\d{2})\d{4}(\d{2,})$/, '$1****$2').replace(/(\d{2})\d{4}(\d{4})$/, '$1****$2');
const buckets = new Map();
function limit(key, max, ms) { const t = now(), b = buckets.get(key) || { n: 0, r: t + ms }; if (t > b.r) { b.n = 0; b.r = t + ms; } b.n++; buckets.set(key, b); if (b.n > max) throw new HttpErr(429, 'Too many requests, slow down'); }
setInterval(() => { const t = now(); for (const [k, b] of buckets) if (t > b.r) buckets.delete(k); }, 60000).unref();

/* ---------- auth ---------- */
function authUser(req) {
  const h = req.headers.authorization || ''; const tok = h.startsWith('Bearer ') ? h.slice(7) : null; if (!tok) throw new HttpErr(401, 'Login required');
  const s = get('SELECT s.user_id,s.expires FROM sessions s WHERE token_hash=?', sha(tok)); if (!s || s.expires < now()) throw new HttpErr(401, 'Session expired');
  return get('SELECT * FROM users WHERE id=?', s.user_id);
}
const needRole = (u, r) => { if (u.role !== r) throw forbid('This action is for ' + (r === 'rescue' ? 'Rescue Team' : 'Help & Services') + ' accounts'); };
function login(b, ip) {
  limit('login:' + ip, cfg.loginPer10Min, 600000);
  const name = clip(b.name, 60), mobile = String(b.mobile || '').replace(/\D/g, '').slice(-10), role = b.role;
  if (name.length < 2) throw bad('Enter your name'); if (!/^[6-9]\d{9}$/.test(mobile) && !/^\d{10}$/.test(mobile)) throw bad('Enter a valid 10-digit mobile number');
  if (role !== 'rescue' && role !== 'hs') throw bad('Invalid role');
  let u = get('SELECT * FROM users WHERE mobile=? AND role=?', mobile, role);
  if (!u) { const id = rid('u_'), code = role === 'rescue' ? 'RT-' + crypto.randomBytes(3).toString('hex').toUpperCase() : null; run('INSERT INTO users(id,name,mobile,role,team_code,created) VALUES(?,?,?,?,?,?)', id, name, mobile, role, code, now()); u = get('SELECT * FROM users WHERE id=?', id); }
  else if (u.name !== name) { run('UPDATE users SET name=? WHERE id=?', name, u.id); u.name = name; }
  const tok = crypto.randomBytes(32).toString('hex'); run('INSERT INTO sessions VALUES(?,?,?,?)', sha(tok), u.id, now() + cfg.sessionDays * 864e5, now());
  return { token: tok, user: me(u) };
}
const me = u => ({ id: u.id, name: u.name, role: u.role, mobile: u.mobile, teamCode: u.team_code, available: !!u.available, prefs: JSON.parse(u.prefs || '{}') });

/* ---------- realtime (SSE) ---------- */
const clients = new Map(); // userId -> Set(res)
const tickets = new Map(); // one-time SSE tickets
function emit(userId, event, data) { const set = clients.get(userId); if (!set) return; for (const r of set) r.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); }
function emitRole(role, event, data, except) { for (const u of all('SELECT id FROM users WHERE role=?', role)) if (u.id !== except) emit(u.id, event, data); }
setInterval(() => { for (const set of clients.values()) for (const r of set) r.write(': hb\n\n'); }, 25000).unref();

/* ---------- notifications ---------- */
function notify(userId, type, title, body, data = {}, opt = {}) {
  const u = get('SELECT prefs FROM users WHERE id=?', userId); if (!u) return;
  const prefs = JSON.parse(u.prefs || '{}'); if (!opt.critical && prefs.nonCritical === false) return; // user may mute non-critical; critical always on
  const id = rid('n_'); try { run('INSERT INTO notifications(id,user_id,type,critical,title,body,data,created,dedupe) VALUES(?,?,?,?,?,?,?,?,?)', id, userId, type, opt.critical ? 1 : 0, title, body, JSON.stringify(data), now(), opt.dedupe || id); }
  catch (e) { return; /* duplicate dedupe key */ }
  emit(userId, 'notification', { id, type, critical: !!opt.critical, title, body, data, created: now() });
}

/* ---------- media ---------- */
const MAGIC = [['image', 'image/jpeg', b => b[0] === 0xFF && b[1] === 0xD8], ['image', 'image/png', b => b.slice(0, 4).toString('hex') === '89504e47'], ['image', 'image/webp', b => b.slice(0, 4).toString() === 'RIFF' && b.slice(8, 12).toString() === 'WEBP'],
  ['video', 'video/mp4', b => b.slice(4, 8).toString() === 'ftyp'], ['video', 'video/webm', b => b.slice(0, 4).toString('hex') === '1a45dfa3']];
function saveMedia(reqId, owner, buf, hintKind) {
  const m = MAGIC.find(x => x[2](buf)); if (!m) throw bad('Unsupported file type (allowed: JPEG, PNG, WebP, MP4, WebM)');
  const [kind, mime] = m; if (hintKind && hintKind !== kind) throw bad('File type does not match');
  if (kind === 'image' && buf.length > cfg.maxImageMb * 1048576) throw bad(`Image too large (max ${cfg.maxImageMb} MB)`);
  if (kind === 'video' && buf.length > cfg.maxVideoMb * 1048576) throw bad(`Video too large (max ${cfg.maxVideoMb} MB)`);
  const c = get('SELECT COUNT(*) n FROM media WHERE request_id=? AND kind=?', reqId, kind).n; if (c >= (kind === 'image' ? cfg.maxImagesPerRequest : cfg.maxVideosPerRequest)) throw bad(`Too many ${kind}s on this request`);
  const id = rid('m_'), file = id + '.bin'; fs.writeFileSync(path.join(cfg.mediaDir, file), buf, { mode: 0o600 });
  run('INSERT INTO media VALUES(?,?,?,?,?,?,?,?)', id, reqId, owner, kind, mime, buf.length, file, now()); return id;
}
const signUrl = (id) => { const exp = Math.floor(now() / 1000) + cfg.signedUrlSeconds; return `/api/media/${id}?exp=${exp}&sig=${hmac(id + '.' + exp)}`; };
const mediaFor = (reqId) => all('SELECT id,kind,mime,size FROM media WHERE request_id=?', reqId).map(m => ({ id: m.id, kind: m.kind, mime: m.mime, size: m.size, url: signUrl(m.id) }));
const dataUrl = s => { const m = /^data:([a-z\/+-]+);base64,([A-Za-z0-9+\/=]+)$/.exec(s || ''); return m ? Buffer.from(m[2], 'base64') : null; };

/* ---------- requests ---------- */
const SERVICE_CATS = ['Medicines', 'Food', 'Water', 'Drinking Water', 'Clothing', 'Shelter', 'Essential Supplies', 'Other'], EM_CATS = ['Fire', 'Flood', 'Crime', 'Accident', 'Earthquake', 'Medical'];
const STATUSES = ['Pending', 'Accepted', 'In Progress', 'Completed', 'Cancelled', 'Rejected', 'Expired'];
function hist(id, status, by, note) { run('INSERT INTO status_history(request_id,status,by_user,at,note) VALUES(?,?,?,?,?)', id, status, by, now(), note || null); }
function createRequest(u, b) {
  needRole(u, 'hs'); limit('create:' + u.id, 20, 60000);
  const kind = b.kind; if (!['help', 'service', 'emergency'].includes(kind)) throw bad('Invalid request kind');
  const id = clip(b.id, 40); if (!/^[A-Za-z0-9_-]{6,40}$/.test(id)) throw bad('Request id required (used to prevent duplicates)');
  const ex = get('SELECT * FROM requests WHERE id=?', id); if (ex) { if (ex.user_id !== u.id) throw new HttpErr(409, 'Id already used'); return { request: ownerView(ex), duplicate: true }; }
  const desc = clip(b.description, 2000), loc = b.loc, place = clip(b.place, 200), district = clip(b.district, 80), pin = clip(b.pin, 6);
  if (pin && !/^\d{6}$/.test(pin)) throw bad('PIN code must be 6 digits');
  if (loc && !validLoc(loc)) throw bad('Invalid GPS coordinates');
  const images = (Array.isArray(b.images) ? b.images : []).slice(0, cfg.maxImagesPerRequest); const bufs = images.map(s => { const x = dataUrl(s); if (!x) throw bad('Image must be a base64 data URL'); return x; });
  let category = clip(b.category, 40), item = null, qty = null, priority = 'high';
  if (kind === 'help') { if (!desc && !bufs.length && !loc && !place) throw bad('Add a description, image or location'); }
  if (kind === 'service') { if (!SERVICE_CATS.includes(category)) throw bad('Invalid service category'); qty = parseInt(b.qty, 10); if (!(qty >= 1 && qty <= 999)) throw bad('Quantity must be 1-999'); item = category; priority = category === 'Medicines' ? 'urgent' : 'normal'; }
  if (kind === 'emergency') { if (!EM_CATS.includes(category)) throw bad('Choose the kind of emergency'); priority = 'critical'; }
  const t = now();
  db.exec('BEGIN'); try {
    run('INSERT INTO requests(id,kind,user_id,category,item,qty,description,priority,status,lat,lon,acc,place,district,pin,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', id, kind, u.id, category || null, item, qty, desc, priority, 'Pending', loc ? +loc.lat : null, loc ? +loc.lon : null, loc ? +loc.acc || null : null, place, district, pin, t, t);
    hist(id, 'Pending', u.id, 'Created'); bufs.forEach(buf => saveMedia(id, u.id, buf, 'image')); db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  if (loc) run('INSERT INTO locations(user_id,lat,lon,acc,place,district,pin,ts) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET lat=excluded.lat,lon=excluded.lon,acc=excluded.acc,place=COALESCE(NULLIF(excluded.place,\'\'),place),ts=excluded.ts', u.id, +loc.lat, +loc.lon, +loc.acc || null, place, district, pin, t);
  const r = get('SELECT * FROM requests WHERE id=?', id);
  const label = { help: 'Help request', service: 'Service request', emergency: 'EMERGENCY' }[kind];
  for (const rs of all("SELECT id FROM users WHERE role='rescue' AND available=1")) {
    if (!visibleTo(r, rs.id)) continue;
    notify(rs.id, kind, label, `${u.name} · ${category || 'New request'}`, { id, kind }, { critical: kind === 'emergency', dedupe: 'new:' + id }); emit(rs.id, 'request', { id, kind, status: 'Pending' });
  }
  emit(u.id, 'request', { id, kind, status: 'Pending' });
  return { request: ownerView(r), duplicate: false };
}
function hsLocation(r) { return r.lat != null ? { lat: r.lat, lon: r.lon, acc: r.acc } : null; }
function ownerView(r) {
  const as = r.assigned_to ? get('SELECT name,team_code FROM users WHERE id=?', r.assigned_to) : null;
  return { id: r.id, kind: r.kind, category: r.category, item: r.item, qty: r.qty, description: r.description, priority: r.priority, status: r.status, loc: hsLocation(r), place: r.place, district: r.district, pin: r.pin, created: r.created, updated: r.updated, completed: r.completed,
    assignedTeam: as ? { name: as.name, teamCode: as.team_code } : null, history: all('SELECT status,at,note FROM status_history WHERE request_id=? ORDER BY id', r.id).map(h => ({ status: h.status, at: h.at, note: h.note })), media: mediaFor(r.id) };
}
function rescueLoc(uid, q) { if (q && validLoc(q)) return { lat: +q.lat, lon: +q.lon }; const l = get('SELECT lat,lon FROM locations WHERE user_id=?', uid); return l && l.lat != null ? l : null; }
function visibleTo(r, uid) {
  if (r.status === 'Pending') { if (get('SELECT 1 x FROM declines WHERE request_id=? AND user_id=?', r.id, uid)) return false; if (!cfg.visibleRadiusKm || r.kind === 'emergency') return true; const l = rescueLoc(uid); if (!l || r.lat == null) return true; return hav(l.lat, l.lon, r.lat, r.lon) <= cfg.visibleRadiusKm; }
  return r.assigned_to === uid; // after acceptance only the assigned Rescue member keeps access
}
function rescueView(r, loc) {
  const owner = get('SELECT name,mobile FROM users WHERE id=?', r.user_id), mine = r.assigned_to != null;
  const reveal = r.kind === 'emergency' || mine; // minimum-necessary: phone hidden on help/service until accepted
  let dist = null; if (loc && r.lat != null) dist = Math.round(hav(loc.lat, loc.lon, r.lat, r.lon) * 10) / 10;
  return { id: r.id, kind: r.kind, category: r.category, item: r.item, qty: r.qty, description: r.description, priority: r.priority, status: r.status, name: owner.name, phone: reveal ? '+91 ' + owner.mobile : '+91 ' + maskPhone(owner.mobile),
    loc: hsLocation(r), place: r.place, district: r.district, pin: r.pin, created: r.created, completed: r.completed, distanceKm: dist, nearby: dist != null && dist <= cfg.nearbyKm, assignedToMe: mine, media: mediaFor(r.id) };
}
function listFor(u, qs) {
  if (u.role === 'hs') return all('SELECT * FROM requests WHERE user_id=? ORDER BY created DESC LIMIT 200', u.id).map(ownerView);
  const loc = rescueLoc(u.id, { lat: qs.get('lat'), lon: qs.get('lon') });
  const rows = all("SELECT * FROM requests WHERE status='Pending' OR assigned_to=? ORDER BY created DESC LIMIT 500", u.id).filter(r => visibleTo(r, u.id)).map(r => rescueView(r, loc));
  // nearest first; unknown distance is never invented – those go after, newest first
  rows.sort((a, b) => (a.distanceKm == null) - (b.distanceKm == null) || (a.distanceKm ?? 0) - (b.distanceKm ?? 0) || b.created - a.created);
  return { rescueLocationKnown: !!loc, nearbyKm: cfg.nearbyKm, requests: rows };
}
const NEXT = { Pending: ['Accepted', 'Rejected', 'Completed'], Accepted: ['In Progress', 'Completed'], 'In Progress': ['Completed'] };
function setStatus(u, id, status, note) {
  if (!STATUSES.includes(status)) throw bad('Invalid status'); const r = get('SELECT * FROM requests WHERE id=?', id); if (!r) throw nf();
  if (u.role === 'hs') { // owner may only cancel own request
    if (r.user_id !== u.id) throw nf(); if (status !== 'Cancelled') throw forbid('You can only cancel your own request'); if (!['Pending', 'Accepted'].includes(r.status)) throw bad('Request can no longer be cancelled');
  } else {
    if (!visibleTo(r, u.id)) throw nf();
    if (status === 'Rejected' && r.status === 'Pending') { run('INSERT OR IGNORE INTO declines VALUES(?,?)', id, u.id); return rescueView(get('SELECT * FROM requests WHERE id=?', id), rescueLoc(u.id)); } // per-team decline, request stays open for others
    if (r.status === status) return rescueView(r, rescueLoc(u.id));
    if (!(NEXT[r.status] || []).includes(status)) throw bad(`Cannot change ${r.status} to ${status}`);
  }
  const t = now(); let assigned = r.assigned_to;
  if (u.role === 'rescue') { if (r.status === 'Pending') { const w = run("UPDATE requests SET assigned_to=?,status=?,updated=?,completed=? WHERE id=? AND status='Pending' AND assigned_to IS NULL", u.id, status, t, status === 'Completed' ? t : null, id); if (!w.changes) throw new HttpErr(409, 'Already taken by another team'); assigned = u.id; } else run('UPDATE requests SET status=?,updated=?,completed=? WHERE id=?', status, t, status === 'Completed' ? t : null, id); }
  else run('UPDATE requests SET status=?,updated=? WHERE id=?', status, t, id);
  hist(id, status, u.id, note);
  const nr = get('SELECT * FROM requests WHERE id=?', id), who = u.role === 'rescue' ? u.name : 'You';
  if (u.role === 'rescue') notify(r.user_id, 'status', `Request ${status}`, `${nr.kind === 'emergency' ? 'Your emergency report' : 'Your ' + nr.kind + ' request'} is now ${status} (${u.name}).`, { id, status }, { critical: nr.kind !== 'service', dedupe: `st:${id}:${status}` });
  else for (const x of all("SELECT id FROM users WHERE id=?", r.assigned_to || '')) notify(x.id, 'status', 'Request cancelled', 'The requester cancelled.', { id, status }, { dedupe: `st:${id}:${status}` });
  emit(r.user_id, 'request', { id, kind: r.kind, status }); if (assigned) emit(assigned, 'request', { id, kind: r.kind, status });
  if (status === 'Accepted') emitRole('rescue', 'request', { id, kind: r.kind, status }, assigned); // others drop it from their list
  return u.role === 'rescue' ? rescueView(nr, rescueLoc(u.id)) : ownerView(nr);
}
function expireSweep() {
  const lim = now() - cfg.expireHours * 36e5; for (const r of all("SELECT * FROM requests WHERE status='Pending' AND created<?", lim)) {
    run("UPDATE requests SET status='Expired',updated=? WHERE id=? AND status='Pending'", now(), r.id); hist(r.id, 'Expired', null, 'No team responded in time');
    notify(r.user_id, 'status', 'Request expired', 'No Rescue Team responded in time. Please submit again or call local emergency services.', { id: r.id }, { critical: true, dedupe: `st:${r.id}:Expired` }); emit(r.user_id, 'request', { id: r.id, kind: r.kind, status: 'Expired' });
  }
}
setInterval(expireSweep, 60000).unref();

/* ---------- teams / connect ---------- */
function connectTeam(u, code) {
  needRole(u, 'rescue'); code = clip(code, 20).toUpperCase(); const t = get("SELECT * FROM users WHERE team_code=? AND role='rescue'", code); if (!t) throw nf('No team with that ID'); if (t.id === u.id) throw bad('You cannot connect to your own team');
  const dup = get('SELECT * FROM connections WHERE (from_user=? AND to_user=?) OR (from_user=? AND to_user=?)', u.id, t.id, t.id, u.id); if (dup) throw new HttpErr(409, dup.status === 'accepted' ? 'Already connected' : 'Request already pending');
  const id = rid('c_'); run('INSERT INTO connections VALUES(?,?,?,?,?)', id, u.id, t.id, 'pending', now());
  notify(t.id, 'connect', 'Team connection request', `${u.name} (${u.team_code}) wants to connect.`, { id }, { dedupe: 'conn:' + id }); return { id, status: 'pending', team: { name: t.name, teamCode: t.team_code } };
}
function connections(u) { return all('SELECT * FROM connections WHERE from_user=? OR to_user=?', u.id, u.id).map(c => { const o = get('SELECT name,team_code FROM users WHERE id=?', c.from_user === u.id ? c.to_user : c.from_user); return { id: c.id, status: c.status, incoming: c.to_user === u.id, team: { name: o.name, teamCode: o.team_code } }; }); }
function respondConn(u, id, accept) { const c = get('SELECT * FROM connections WHERE id=? AND to_user=? AND status=?', id, u.id, 'pending'); if (!c) throw nf(); if (accept) run("UPDATE connections SET status='accepted' WHERE id=?", id); else run('DELETE FROM connections WHERE id=?', id); notify(c.from_user, 'connect', accept ? 'Connection accepted' : 'Connection declined', `${u.name} ${accept ? 'accepted' : 'declined'} your request.`, { id }, { dedupe: `connr:${id}:${accept}` }); return { id, status: accept ? 'accepted' : 'declined' }; }

/* ---------- http plumbing ---------- */
function readBody(req, max) {
  return new Promise((res, rej) => { const ch = []; let n = 0; req.on('data', d => { n += d.length; if (n > max) { rej(new HttpErr(413, 'Upload too large')); req.destroy(); } else ch.push(d); }); req.on('end', () => res(Buffer.concat(ch))); req.on('error', rej); });
}
const json = async (req, max = 14 * 1048576) => { const b = await readBody(req, max); if (!b.length) return {}; try { return JSON.parse(b.toString()); } catch (e) { throw bad('Invalid JSON'); } };
const routes = [];
const R = (m, p, fn) => routes.push([m, new RegExp('^' + p.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn]);
const authed = fn => async (c) => fn(c, authUser(c.req));
R('GET', '/api/health', async () => ({ ok: true, time: now(), features: { realtime: true, disasterMonitor: cfg.disaster.enabled, push: false, otp: false } }));
R('POST', '/api/auth/login', async c => login(await json(c.req, 20000), c.ip));
R('POST', '/api/auth/logout', async c => { const t = (c.req.headers.authorization || '').slice(7); if (t) run('DELETE FROM sessions WHERE token_hash=?', sha(t)); return { ok: true }; });
R('GET', '/api/me', authed(async (c, u) => me(u)));
R('PATCH', '/api/me', authed(async (c, u) => { const b = await json(c.req, 20000), name = clip(b.name, 60); if (name.length >= 2) run('UPDATE users SET name=? WHERE id=?', name, u.id); if (typeof b.available === 'boolean' && u.role === 'rescue') run('UPDATE users SET available=? WHERE id=?', b.available ? 1 : 0, u.id); if (b.prefs && typeof b.prefs === 'object') { const p = { ...JSON.parse(u.prefs || '{}'), nonCritical: b.prefs.nonCritical !== false }; run('UPDATE users SET prefs=? WHERE id=?', JSON.stringify(p), u.id); } return me(get('SELECT * FROM users WHERE id=?', u.id)); }));
R('PUT', '/api/me/location', authed(async (c, u) => { const b = await json(c.req, 20000); if (!(validLoc(b) || clip(b.place, 200))) throw bad('Send GPS coordinates or a place name'); const g = validLoc(b); const pin = clip(b.pin, 6); if (pin && !/^\d{6}$/.test(pin)) throw bad('PIN code must be 6 digits');
  run('INSERT INTO locations VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET lat=excluded.lat,lon=excluded.lon,acc=excluded.acc,place=excluded.place,district=excluded.district,pin=excluded.pin,ts=excluded.ts', u.id, g ? +b.lat : null, g ? +b.lon : null, g ? +b.acc || null : null, clip(b.place, 200), clip(b.district, 80), pin, now()); return { ok: true, source: g ? 'gps' : 'manual' }; }));
R('POST', '/api/requests', authed(async (c, u) => createRequest(u, await json(c.req))));
R('GET', '/api/requests', authed(async (c, u) => listFor(u, c.url.searchParams)));
R('PATCH', '/api/requests/:id/status', authed(async (c, u) => { const b = await json(c.req, 20000); return { request: setStatus(u, c.p.id, b.status, clip(b.note, 200)) }; }));
R('POST', '/api/requests/:id/media', authed(async (c, u) => { const r = get('SELECT * FROM requests WHERE id=? AND user_id=?', c.p.id, u.id); if (!r) throw nf(); const buf = await readBody(c.req, cfg.maxVideoMb * 1048576 + 1024); const id = saveMedia(r.id, u.id, buf); emit(u.id, 'request', { id: r.id }); return { id, url: signUrl(id) }; }));
R('GET', '/api/media/:id', async c => { // access-controlled: signed short-lived URL OR bearer token of an authorized user
  const m = get('SELECT * FROM media WHERE id=?', c.p.id); if (!m) throw nf(); const exp = +c.url.searchParams.get('exp'), sig = c.url.searchParams.get('sig') || '';
  const ok = exp > now() / 1000 && sig.length === 64 && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(hmac(m.id + '.' + exp)));
  if (!ok) { const u = authUser(c.req), r = get('SELECT * FROM requests WHERE id=?', m.request_id); if (!(r.user_id === u.id || (u.role === 'rescue' && visibleTo(r, u.id)))) throw forbid(); }
  return { raw: fs.readFileSync(path.join(cfg.mediaDir, m.file)), type: m.mime }; });
R('GET', '/api/notifications', authed(async (c, u) => ({ notifications: all('SELECT id,type,critical,title,body,data,created,read FROM notifications WHERE user_id=? ORDER BY created DESC LIMIT 100', u.id).map(n => ({ ...n, critical: !!n.critical, read: !!n.read, data: JSON.parse(n.data || '{}') })) })));
R('POST', '/api/notifications/read', authed(async (c, u) => { run('UPDATE notifications SET read=1 WHERE user_id=?', u.id); return { ok: true }; }));
R('POST', '/api/events/ticket', authed(async (c, u) => { const t = crypto.randomBytes(16).toString('hex'); tickets.set(t, { id: u.id, exp: now() + 30000 }); return { ticket: t }; }));
R('GET', '/api/events', async c => { const t = tickets.get(c.url.searchParams.get('ticket')); tickets.delete(c.url.searchParams.get('ticket')); if (!t || t.exp < now()) throw new HttpErr(401, 'Invalid ticket'); return { sse: t.id }; });
R('POST', '/api/connect', authed(async (c, u) => connectTeam(u, (await json(c.req, 5000)).teamCode)));
R('GET', '/api/connections', authed(async (c, u) => ({ connections: connections(u) })));
R('POST', '/api/connections/:id/respond', authed(async (c, u) => respondConn(u, c.p.id, !!(await json(c.req, 2000)).accept)));
R('GET', '/api/disasters', authed(async (c, u) => ({ alerts: require('./disaster').activeFor(u.id) })));
R('GET', '/api/disasters/status', authed(async () => require('./disaster').status()));

const MIME = { '.html': 'text/html; charset=utf-8' };
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x'), ip = req.socket.remoteAddress;
  const hdr = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Cache-Control': 'no-store', 'X-Frame-Options': 'DENY' };
  const origin = req.headers.origin; if (origin && cfg.allowedOrigins.includes(origin)) Object.assign(hdr, { 'Access-Control-Allow-Origin': origin, 'Vary': 'Origin', 'Access-Control-Allow-Headers': 'Content-Type,Authorization', 'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,OPTIONS' });
  if (req.method === 'OPTIONS') { res.writeHead(204, hdr); return res.end(); }
  try {
    if (!url.pathname.startsWith('/api/')) { // static: only the two prototype files
      const f = { '/': 'index.html', '/index.html': 'index.html', '/app.html': 'app.html' }[url.pathname]; if (!f) throw nf();
      res.writeHead(200, { ...hdr, 'Content-Type': MIME['.html'] }); return res.end(fs.readFileSync(path.join(cfg.staticDir, f)));
    }
    limit('ip:' + ip, cfg.rateLimitPerMin, 60000);
    for (const [m, re, fn] of routes) {
      if (m !== req.method) continue; const mt = re.exec(url.pathname); if (!mt) continue;
      const out = await fn({ req, res, url, ip, p: mt.groups || {} });
      if (out && out.raw) { res.writeHead(200, { ...hdr, 'Content-Type': out.type, 'Cache-Control': 'private, max-age=300' }); return res.end(out.raw); }
      if (out && out.sse) { res.writeHead(200, { ...hdr, 'Content-Type': 'text/event-stream', Connection: 'keep-alive' }); res.write('retry: 3000\n\n'); const set = clients.get(out.sse) || new Set(); set.add(res); clients.set(out.sse, set); req.on('close', () => { set.delete(res); if (!set.size) clients.delete(out.sse); }); return; }
      res.writeHead(200, { ...hdr, 'Content-Type': 'application/json' }); return res.end(JSON.stringify(out));
    }
    throw nf();
  } catch (e) {
    const s = e.status || 500; if (s === 500) console.error(e);
    res.writeHead(s, { ...hdr, 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: s === 500 ? 'Server error' : e.message }));
  }
});
module.exports = { server, notify, emit, db, cfg, hav };
if (require.main === module) {
  server.listen(cfg.port, cfg.host, () => console.log(`RESQURA backend on :${cfg.port} (${cfg.prod ? 'production' : 'dev'})`));
  if (cfg.disaster.enabled) require('./disaster').start();
  process.on('SIGTERM', () => server.close(() => process.exit(0)));
}
