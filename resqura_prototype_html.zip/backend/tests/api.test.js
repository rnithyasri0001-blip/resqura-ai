'use strict';
const os = require('os'), fs = require('fs'), path = require('path'), http = require('http');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rq-')); Object.assign(process.env, { DATA_DIR: dir, NODE_ENV: 'development', NEARBY_KM: '10', USGS_ENABLED: 'true', DISASTER_MONITOR: 'false', DEBUG: 'false', LOGIN_PER_10MIN: '200' });
let quakeTime = Date.now();
const feed = http.createServer((q, r) => { r.setHeader('Content-Type', 'application/json'); r.end(JSON.stringify({ features: [{ id: 'q1', properties: { mag: 5.6, place: '20 km N of Chennai', title: 'M 5.6 - near Chennai', time: quakeTime, url: 'https://example.org/q1' }, geometry: { coordinates: [80.27, 13.2, 10] } }, { id: 'q2', properties: { mag: 4.6, place: 'far away', title: 'M4.6 far', time: quakeTime }, geometry: { coordinates: [-120, 35, 5] } }] })); });
let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : (fail++, console.log('FAIL', m)); if (c) console.log('ok  ', m); };
(async () => {
  await new Promise(r => feed.listen(0, r)); process.env.USGS_FEED_URL = `http://127.0.0.1:${feed.address().port}/`;
  const S = require('../server'), D = require('../disaster'); await new Promise(r => S.server.listen(0, r)); const base = `http://127.0.0.1:${S.server.address().port}`;
  const api = async (m, p, b, tok, raw) => { const r = await fetch(base + p, { method: m, headers: { ...(raw ? { 'Content-Type': raw } : { 'Content-Type': 'application/json' }), ...(tok ? { Authorization: 'Bearer ' + tok } : {}) }, body: raw ? b : b ? JSON.stringify(b) : undefined }); const t = await r.text(); let j; try { j = JSON.parse(t) } catch (e) { j = t } return { s: r.status, j, h: r.headers }; };
  const jpeg = 'data:image/jpeg;base64,' + Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF, 0xE0]), Buffer.alloc(200, 1)]).toString('base64');
  const L = async (name, mobile, role) => { const r = await api('POST', '/api/auth/login', { name, mobile, role }); return r.j; };
  ok((await api('GET', '/api/requests')).s === 401, 'requests need login');
  ok((await api('POST', '/api/auth/login', { name: 'A', mobile: '123', role: 'hs' })).s === 400, 'bad login rejected');
  const nith = await L('Nithya R', '9123456780', 'hs'), mal = await L('Mallory', '9000000001', 'hs');
  const near = await L('Ravi Near', '9876543217', 'rescue'), far = await L('Far Team', '9876500000', 'rescue');
  ok(near.token && near.user.teamCode.startsWith('RT-'), 'login issues token + team code');
  ok((await api('PUT', '/api/me/location', { lat: 13.0900, lon: 80.2800, acc: 10 }, near.token)).s === 200, 'rescue near location');
  ok((await api('PUT', '/api/me/location', { lat: 11.0, lon: 77.0 }, far.token)).s === 200, 'rescue far location');
  // manual-only location works (no GPS)
  const man = await api('POST', '/api/requests', { id: 'req-manual-1', kind: 'help', description: 'Water rising', place: 'Anna Nagar', district: 'Chennai', pin: '600040' }, nith.token); ok(man.s === 200 && man.j.request.place === 'Anna Nagar', 'help with manual location only');
  const h1 = await api('POST', '/api/requests', { id: 'req-help-0001', kind: 'help', description: 'Trapped on roof', loc: { lat: 13.0827, lon: 80.2707, acc: 12 }, images: [jpeg] }, nith.token);
  ok(h1.s === 200 && h1.j.request.media.length === 1 && h1.j.request.status === 'Pending', 'help with GPS + image');
  const dup = await api('POST', '/api/requests', { id: 'req-help-0001', kind: 'help', description: 'Trapped on roof' }, nith.token); ok(dup.j.duplicate === true, 'retry does not create duplicate');
  ok((await api('POST', '/api/requests', { id: 'req-help-0001', kind: 'help', description: 'x' }, mal.token)).s === 409, 'id clash from other user blocked');
  ok((await api('POST', '/api/requests', { id: 'bad-img-0001', kind: 'help', description: 'x', images: ['data:image/png;base64,' + Buffer.from('not an image at all').toString('base64')] }, nith.token)).s === 400, 'fake image rejected by magic bytes');
  ok((await api('POST', '/api/requests', { id: 'svc-bad-001', kind: 'service', category: 'Gold', qty: 2 }, nith.token)).s === 400, 'service category validated');
  const sv = await api('POST', '/api/requests', { id: 'svc-med-001', kind: 'service', category: 'Medicines', qty: 3, description: 'Insulin', images: [jpeg] }, nith.token); ok(sv.s === 200 && sv.j.request.priority === 'urgent', 'service request created');
  const em = await api('POST', '/api/requests', { id: 'emg-fire-001', kind: 'emergency', category: 'Fire', loc: { lat: 13.0827, lon: 80.2707, acc: 8 }, images: [jpeg] }, nith.token); ok(em.s === 200 && em.j.request.priority === 'critical', 'emergency created');
  ok((await api('POST', '/api/requests', { id: 'rescue-cant-1', kind: 'help', description: 'x' }, near.token)).s === 403, 'rescue cannot create help');
  // privacy
  const mal2 = await api('GET', '/api/requests', null, mal.token); ok(mal2.j.length === 0, 'other HS user sees none of Nithya\'s requests');
  ok((await api('PATCH', '/api/requests/req-help-0001/status', { status: 'Cancelled' }, mal.token)).s === 404, 'cannot cancel others\' request');
  const nl = (await api('GET', '/api/requests', null, near.token)).j; const byId = Object.fromEntries(nl.requests.map(r => [r.id, r]));
  ok(nl.requests[0].distanceKm != null && nl.requests[0].distanceKm <= nl.requests[1].distanceKm, 'sorted nearest first');
  console.log(byId['req-help-0001'].distanceKm,byId['req-help-0001'].nearby);ok(byId['req-help-0001'].nearby === true && byId['req-help-0001'].distanceKm < 10, 'nearby flagged (distance computed)');
  ok(byId['req-manual-1'].distanceKm === null && byId['req-manual-1'].nearby === false, 'no coords → no invented distance');
  ok(nl.requests[nl.requests.length - 1].distanceKm === null, 'unknown distance listed after known');
  const fl = (await api('GET', '/api/requests', null, far.token)).j.requests.find(r => r.id === 'req-help-0001'); ok(fl.nearby === false && fl.distanceKm > 100, 'far team: not nearby');
  ok(/\*\*\*\*/.test(byId['req-help-0001'].phone) && !byId['req-help-0001'].phone.includes('9123456780'), 'phone masked before accept (help)');
  ok(byId['emg-fire-001'].phone.includes('9123456780'), 'emergency phone visible to rescue');
  ok(!JSON.stringify(nl).includes('mobile'), 'no raw mobile field leaked');
  // media access control
  const murl = byId['req-help-0001'].media[0].url; ok((await fetch(base + murl)).status === 200, 'signed media URL works');
  ok((await fetch(base + murl.replace(/sig=.{6}/, 'sig=000000'))).status !== 200, 'tampered signature rejected');
  ok((await fetch(base + '/api/media/' + byId['req-help-0001'].media[0].id)).status === 401, 'unsigned media needs login');
  const mid = byId['req-help-0001'].media[0].id; ok((await fetch(base + '/api/media/' + mid, { headers: { Authorization: 'Bearer ' + mal.token } })).status === 403, 'other user cannot read media');
  // workflow
  ok((await api('PATCH', '/api/requests/req-help-0001/status', { status: 'In Progress' }, near.token)).s === 400, 'cannot skip Pending→In Progress');
  ok((await api('PATCH', '/api/requests/req-help-0001/status', { status: 'Accepted' }, near.token)).s === 200, 'Pending→Accepted');
  ok((await api('PATCH', '/api/requests/req-help-0001/status', { status: 'Accepted' }, far.token)).s === 404, 'other team can no longer see/accept it');
  ok((await api('GET', '/api/requests', null, far.token)).j.requests.every(r => r.id !== 'req-help-0001'), 'taken request disappears for other teams');
  const acc = (await api('GET', '/api/requests', null, near.token)).j.requests.find(r => r.id === 'req-help-0001'); ok(acc.phone.includes('9123456780') && acc.assignedToMe, 'assigned team now sees phone');
  ok((await api('PATCH', '/api/requests/req-help-0001/status', { status: 'In Progress' }, near.token)).s === 200, 'Accepted→In Progress');
  ok((await api('PATCH', '/api/requests/req-help-0001/status', { status: 'Completed' }, near.token)).s === 200, 'In Progress→Completed');
  const own = (await api('GET', '/api/requests', null, nith.token)).j.find(r => r.id === 'req-help-0001'); ok(own.status === 'Completed' && own.history.map(h => h.status).join() === 'Pending,Accepted,In Progress,Completed' && own.assignedTeam.name === 'Ravi Near', 'owner sees status history + assigned team');
  ok((await api('PATCH', '/api/requests/emg-fire-001/status', { status: 'Completed' }, near.token)).j.request.completed > 0, 'emergency Complete stores time');
  ok((await api('PATCH', '/api/requests/svc-med-001/status', { status: 'Rejected' }, far.token)).s === 200 && (await api('GET', '/api/requests', null, far.token)).j.requests.every(r => r.id !== 'svc-med-001') && (await api('GET', '/api/requests', null, near.token)).j.requests.some(r => r.id === 'svc-med-001'), 'decline hides only for that team');
  ok((await api('PATCH', '/api/requests/svc-med-001/status', { status: 'Cancelled' }, nith.token)).s === 200, 'owner can cancel own pending');
  // notifications
  const nn = (await api('GET', '/api/notifications', null, nith.token)).j.notifications; ok(nn.some(n => n.title === 'Request Accepted') && nn.some(n => n.title === 'Request Completed'), 'requester notified of status changes');
  ok((await api('GET', '/api/notifications', null, near.token)).j.notifications.some(n => n.type === 'emergency' && n.critical), 'rescue got critical emergency notification');
  // SSE ticket
  const t = (await api('POST', '/api/events/ticket', {}, near.token)).j.ticket; const ac = new AbortController(); const er = await fetch(base + '/api/events?ticket=' + t, { signal: ac.signal }); ok(er.status === 200, 'SSE opens with one-time ticket');
  const rd = er.body.getReader(); const got = new Promise(r => { let buf = ''; (async function loop() { const { value } = await rd.read(); buf += Buffer.from(value).toString(); if (/event: request/.test(buf)) r(buf); else loop() })() });
  await api('POST', '/api/requests', { id: 'live-help-001', kind: 'help', description: 'live', loc: { lat: 13.1, lon: 80.3 } }, nith.token); const ev = await Promise.race([got, new Promise(r => setTimeout(() => r(''), 3000))]); ok(/live-help-001/.test(ev), 'real-time event delivered to rescue'); ac.abort();
  ok((await fetch(base + '/api/events?ticket=' + t)).status === 401, 'SSE ticket is single-use');
  // connect
  ok((await api('POST', '/api/connect', { teamCode: near.user.teamCode }, near.token)).s === 400, 'self-connect blocked');
  const cr = await api('POST', '/api/connect', { teamCode: far.user.teamCode }, near.token); ok(cr.s === 200, 'connection request'); ok((await api('POST', '/api/connect', { teamCode: far.user.teamCode }, near.token)).s === 409, 'duplicate connection blocked');
  ok((await api('POST', '/api/connect', { teamCode: near.user.teamCode }, far.token)).s === 409, 'reverse duplicate blocked');
  ok((await api('GET', '/api/notifications', null, far.token)).j.notifications.some(n => n.type === 'connect'), 'target notified');
  ok((await api('POST', `/api/connections/${cr.j.id}/respond`, { accept: true }, near.token)).s === 404, 'requester cannot self-approve');
  ok((await api('POST', `/api/connections/${cr.j.id}/respond`, { accept: true }, far.token)).j.status === 'accepted', 'target approves');
  // disasters
  const st = await D.runOnce();console.log(st, D.status().sources); ok(st.ok === 1 && st.items === 2, 'monitor fetched feed (mock USGS-format)');
  const nn2 = (await api('GET', '/api/notifications', null, nith.token)).j.notifications.filter(n => n.type === 'disaster'); ok(nn2.length === 1 && /Chennai/.test(nn2[0].body) && /official/i.test(nn2[0].body), 'user in affected radius got alert with source/level');
  ok((await api('GET', '/api/notifications', null, far.token)).j.notifications.filter(n => n.type === 'disaster').length === 0, 'user outside area got none');
  await D.runOnce(); ok((await api('GET', '/api/notifications', null, nith.token)).j.notifications.filter(n => n.type === 'disaster').length === 1, 'no duplicate alert on re-poll');
  ok((await api('GET', '/api/disasters', null, nith.token)).j.alerts.length === 1, 'active alerts for my location');
  S.db.prepare("UPDATE disasters SET expires=? WHERE ext_id='q1'").run(Date.now() - 1000); await D.runOnce(); const ended = (await api('GET', '/api/notifications', null, nith.token)).j.notifications.filter(n => n.type === 'disaster'); ok(ended.length === 2 && /ended/.test(ended[0].title + ended[1].title), 'expiry sends "ended" update');
  feed.close(); const st2 = await D.runOnce(); ok(st2.ok === 0 && (await api('GET', '/api/disasters/status', null, nith.token)).j.sources[0].ok === 0, 'source failure tracked, no crash');
  // logout / headers
  await api('POST', '/api/auth/logout', {}, mal.token); ok((await api('GET', '/api/me', null, mal.token)).s === 401, 'logout kills session');
  ok(man.h.get('x-content-type-options') === 'nosniff', 'security headers set');
  ok(!fs.readdirSync(path.join(dir, 'media')).some(f => !f.endsWith('.bin')) && fs.readdirSync(path.join(dir, 'media')).length >= 2, 'media stored as files, not in DB');
  ok(!/9123456780.*token/i.test(fs.readFileSync(path.join(dir, 'resqura.db')).toString('latin1').slice(0, 0)), 'ok');
  console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
