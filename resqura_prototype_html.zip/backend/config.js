'use strict';
// Central configuration. Everything comes from environment variables (.env file optional). No secrets in code.
const fs = require('fs'), path = require('path'), crypto = require('crypto');
try { // tiny .env loader (no dependency)
  for (const l of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/); if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch (e) {}
const E = process.env, num = (k, d) => (E[k] !== undefined && E[k] !== '' && !isNaN(+E[k]) ? +E[k] : d), bool = (k, d) => (E[k] === undefined ? d : /^(1|true|yes|on)$/i.test(E[k]));
const dataDir = path.resolve(E.DATA_DIR || path.join(__dirname, 'data'));
fs.mkdirSync(dataDir, { recursive: true });
const prod = E.NODE_ENV === 'production';
let secret = E.AUTH_SECRET;
if (!secret) {
  if (prod) { console.error('AUTH_SECRET is required in production'); process.exit(1); }
  const f = path.join(dataDir, '.dev-secret'); // dev only: generated locally, never shipped
  try { secret = fs.readFileSync(f, 'utf8'); } catch (e) { secret = crypto.randomBytes(32).toString('hex'); fs.writeFileSync(f, secret, { mode: 0o600 }); }
}
let feeds = []; try { feeds = JSON.parse(E.EXTRA_ALERT_FEEDS || '[]'); } catch (e) { console.error('EXTRA_ALERT_FEEDS is not valid JSON'); }
module.exports = {
  prod, debug: bool('DEBUG', !prod), port: num('PORT', 8080), host: E.HOST || '0.0.0.0',
  dataDir, dbPath: path.resolve(E.DB_PATH || path.join(dataDir, 'resqura.db')), mediaDir: path.resolve(E.MEDIA_DIR || path.join(dataDir, 'media')),
  staticDir: path.resolve(E.STATIC_DIR || path.join(__dirname, '..', 'flow_pkg')),
  secret, allowedOrigins: (E.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean),
  sessionDays: num('SESSION_DAYS', 30), signedUrlSeconds: num('SIGNED_URL_SECONDS', 600),
  nearbyKm: num('NEARBY_KM', 10),                 // green "nearby" threshold for Rescue Help list
  visibleRadiusKm: num('VISIBLE_RADIUS_KM', 0),   // 0 = every Rescue user sees pending requests; >0 = only within this radius (when both locations known)
  expireHours: num('REQUEST_EXPIRE_HOURS', 24),
  maxImageMb: num('MAX_IMAGE_MB', 8), maxVideoMb: num('MAX_VIDEO_MB', 50), maxImagesPerRequest: num('MAX_IMAGES', 5), maxVideosPerRequest: num('MAX_VIDEOS', 2),
  rateLimitPerMin: num('RATE_LIMIT_PER_MIN', 240), loginPer10Min: num('LOGIN_PER_10MIN', 30),
  disaster: {
    enabled: bool('DISASTER_MONITOR', true), intervalMin: num('DISASTER_INTERVAL_MIN', 10),
    usgsEnabled: bool('USGS_ENABLED', true), usgsUrl: E.USGS_FEED_URL || 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson',
    minMagnitude: num('ALERT_MIN_MAGNITUDE', 4.5), notifyLevels: (E.ALERT_NOTIFY_LEVELS || 'official,trusted').split(',').map(s => s.trim()),
    feeds, // [{name,url,type:'rss',level:'official'|'trusted'|'unverified',kind:'Flood'}]  (e.g. your national CAP/RSS alert feed, IMD, NDMA, a news RSS)
    fetchTimeoutMs: num('DISASTER_FETCH_TIMEOUT_MS', 10000),
  },
  push: { enabled: bool('PUSH_ENABLED', false), vapidPublic: E.VAPID_PUBLIC_KEY || '', vapidPrivate: E.VAPID_PRIVATE_KEY || '' }, // not wired – see README
};
