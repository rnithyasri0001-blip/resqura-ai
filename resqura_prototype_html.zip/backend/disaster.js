'use strict';
// Disaster monitoring: only permitted sources (official feeds / APIs / RSS you configure). No scraping.
// Levels: official (verified government/agency feed) | trusted (reputable news/info) | unverified. Unverified is stored but never pushed to users.
const crypto = require('crypto'); const cfg = require('./config'), db = require('./db'); const C = cfg.disaster;
const now = () => Date.now(), sha = s => crypto.createHash('sha256').update(s).digest('hex').slice(0, 16);
const hav = (a, b, c, d) => { const r = x => x * Math.PI / 180, dl = r(c - a), dn = r(d - b), h = Math.sin(dl / 2) ** 2 + Math.cos(r(a)) * Math.cos(r(c)) * Math.sin(dn / 2) ** 2; return 12742 * Math.asin(Math.sqrt(h)); };
const log = (source, level, msg) => { db.prepare('INSERT INTO monitor_log(at,source,level,msg) VALUES(?,?,?,?)').run(now(), source, level, String(msg).slice(0, 500)); if (cfg.debug) console.log(`[monitor:${source}] ${msg}`); };
const KINDS = [['Tsunami', /tsunami/i], ['Cyclone', /cyclone|hurricane|typhoon/i], ['Flood', /flood|inundat/i], ['Heavy Rain', /heavy rain|rainfall|downpour/i], ['Landslide', /landslide|mudslide/i], ['Wildfire', /wildfire|forest fire/i], ['Earthquake', /earthquake|seismic/i], ['Storm', /storm|thunder|gale|lightning/i]];
const kindOf = t => (KINDS.find(k => k[1].test(t)) || ['Other'])[0];
const SEV = /extreme|severe|red alert|warning/i, MOD = /watch|orange|moderate|advisory|alert/i;
async function fetchText(url) { const ac = new AbortController(), t = setTimeout(() => ac.abort(), C.fetchTimeoutMs); try { const r = await fetch(url, { signal: ac.signal, headers: { 'User-Agent': 'RESQURA-monitor/1.0' } }); if (!r.ok) throw new Error('HTTP ' + r.status); return await r.text(); } finally { clearTimeout(t); } }

function usgs(txt) {
  const j = JSON.parse(txt), out = [];
  for (const f of j.features || []) {
    const p = f.properties || {}, [lon, lat] = (f.geometry || {}).coordinates || []; if (p.mag == null || lat == null || p.mag < C.minMagnitude) continue;
    const m = +p.mag, sev = m >= 7 ? 'Extreme' : m >= 6 ? 'Severe' : m >= 5 ? 'Moderate' : 'Minor', radius = m >= 7 ? 400 : m >= 6 ? 200 : m >= 5 ? 100 : 50; // radius is an estimate of the felt/affected area, not an official zone
    out.push({ ext_id: f.id, type: 'Earthquake', severity: sev, title: p.title || `M${m} earthquake`, area: p.place || '', lat, lon, radius_km: radius, url: p.url, issued: p.time, expires: p.time + 24 * 36e5, status: 'Active', safety: 'Drop, cover and hold on. Move away from buildings and expect aftershocks. Follow local authority instructions.' });
  }
  return out;
}
function rss(txt, f) { // minimal RSS/Atom/CAP-RSS item parser
  const items = txt.match(/<(item|entry)[\s>][\s\S]*?<\/\1>/g) || [], tag = (s, n) => { const m = new RegExp(`<${n}[^>]*>([\\s\\S]*?)</${n}>`, 'i').exec(s); return m ? m[1].replace(/<!\[CDATA\[|\]\]>/g, '').replace(/<[^>]+>/g, '').trim() : ''; };
  return items.map(it => {
    const title = tag(it, 'title'), desc = tag(it, 'description') || tag(it, 'summary'), link = tag(it, 'link') || (/<link[^>]*href="([^"]+)"/.exec(it) || [])[1] || '', guid = tag(it, 'guid') || tag(it, 'id') || link || title;
    const gp = /<georss:point>\s*(-?[\d.]+)\s+(-?[\d.]+)/.exec(it), la = /<geo:lat>\s*(-?[\d.]+)/.exec(it), lo = /<geo:long>\s*(-?[\d.]+)/.exec(it); const pub = Date.parse(tag(it, 'pubDate') || tag(it, 'updated') || tag(it, 'published')) || now();
    const txt = title + ' ' + desc, expTxt = Date.parse(tag(it, 'expires')); const cancelled = /cancel|all clear|withdrawn/i.test(txt);
    return { ext_id: String(guid).slice(0, 200), type: f.kind || kindOf(txt), severity: SEV.test(txt) ? 'Severe' : MOD.test(txt) ? 'Moderate' : 'Minor', title: title.slice(0, 200), area: (f.area || tag(it, 'areaDesc') || '').slice(0, 200), lat: gp ? +gp[1] : la ? +la[1] : null, lon: gp ? +gp[2] : lo ? +lo[1] : null, radius_km: f.radiusKm || (gp || la ? 30 : null), url: link, issued: pub, expires: expTxt || pub + 24 * 36e5, status: cancelled ? 'Cancelled' : 'Active', safety: f.safety || 'Stay alert and follow instructions from official authorities.' };
  });
}
function ingest(source, level, a) {
  for (const k of Object.keys(a)) if (a[k] === undefined) a[k] = null;
  const id = source + ':' + a.ext_id, ver = sha([a.severity, a.status, a.title, a.expires].join('|')); const ex = db.prepare('SELECT * FROM disasters WHERE source=? AND ext_id=?').get(source, a.ext_id);
  if (!ex) { db.prepare('INSERT INTO disasters(id,source,ext_id,type,severity,level,title,area,lat,lon,radius_km,url,safety,issued,expires,status,version,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id, source, a.ext_id, a.type, a.severity, level, a.title, a.area, a.lat, a.lon, a.radius_km, a.url, a.safety, a.issued, a.expires, a.status, ver, now()); return 'new'; }
  if (ex.version !== ver) { db.prepare('UPDATE disasters SET severity=?,title=?,status=?,expires=?,version=?,updated=? WHERE id=?').run(a.severity, a.title, a.status, a.expires, ver, now(), ex.id); return 'updated'; }
  return 'same';
}
function usersInArea(d) { // only users whose saved/current location falls in the affected area
  const out = [], locs = db.prepare('SELECT user_id,lat,lon,place,district FROM locations').all();
  const words = (d.area || '').toLowerCase().split(/[,;\/]| - /).map(s => s.trim()).filter(s => s.length > 3);
  for (const l of locs) {
    if (d.lat != null && d.radius_km && l.lat != null) { if (hav(l.lat, l.lon, d.lat, d.lon) <= d.radius_km) out.push(l.user_id); }
    else if (d.lat == null && words.length) { const t = ((l.district || '') + ' ' + (l.place || '')).toLowerCase(); if (t.trim() && words.some(w => t.includes(w) || w.includes((l.district || '').toLowerCase()) && l.district)) out.push(l.user_id); }
  }
  return out;
}
const { } = {};
function dispatch(d) {
  const S = require('./server'); if (!C.notifyLevels.includes(d.level)) return 0; let n = 0;
  const lab = d.level === 'official' ? 'Official alert' : 'Trusted information (not an official alert)', head = d.status === 'Cancelled' ? `${d.type} alert cancelled` : d.status === 'Expired' ? `${d.type} alert ended` : `${d.severity} ${d.type} warning`;
  for (const uid of usersInArea(d)) {
    const body = `${head}${d.area ? ' – ' + d.area : ''}. ${d.status === 'Active' ? d.safety : 'No further action needed unless instructed.'} Source: ${d.source} (${lab}).${d.url ? ' ' + d.url : ''}`;
    const before = db.prepare('SELECT COUNT(*) c FROM notifications WHERE user_id=?').get(uid).c;
    S.notify(uid, 'disaster', head, body, { id: d.id, level: d.level, severity: d.severity, type: d.type, area: d.area, source: d.source, url: d.url, expires: d.expires }, { critical: d.level === 'official' && d.severity !== 'Minor', dedupe: `dis:${d.id}:${d.version}` });
    if (db.prepare('SELECT COUNT(*) c FROM notifications WHERE user_id=?').get(uid).c > before) n++;
  }
  return n;
}
function sources() { const s = []; if (C.usgsEnabled) s.push({ name: 'USGS', level: 'official', parse: usgs, url: C.usgsUrl }); for (const f of C.feeds) if (f && f.url && f.name) s.push({ name: f.name, level: ['official', 'trusted', 'unverified'].includes(f.level) ? f.level : 'unverified', parse: t => rss(t, f), url: f.url }); return s; }
async function runOnce() {
  const stats = { sources: 0, ok: 0, items: 0, notified: 0 };
  for (const s of sources()) {
    stats.sources++; try {
      const items = s.parse(await fetchText(s.url)); let n = 0;
      for (const a of items) { if (ingest(s.name, s.level, a) !== 'same') { n++; const d = db.prepare('SELECT * FROM disasters WHERE source=? AND ext_id=?').get(s.name, a.ext_id); stats.notified += dispatch(d); } }
      db.prepare('INSERT INTO source_health VALUES(?,?,?,?,?,?) ON CONFLICT(source) DO UPDATE SET ok=1,last_run=excluded.last_run,last_ok=excluded.last_ok,error=NULL,items=excluded.items').run(s.name, 1, now(), now(), null, items.length); stats.ok++; stats.items += items.length; if (n) log(s.name, 'info', `${n} new/changed of ${items.length}`);
    } catch (e) { db.prepare('INSERT INTO source_health VALUES(?,?,?,?,?,?) ON CONFLICT(source) DO UPDATE SET ok=0,last_run=excluded.last_run,error=excluded.error').run(s.name, 0, now(), null, e.message, 0); log(s.name, 'error', e.message); }
  }
  // expire outdated alerts + tell affected users it ended
  for (const d of db.prepare("SELECT * FROM disasters WHERE status='Active' AND expires<?").all(now())) { const ver = sha(d.version + 'expired'); db.prepare("UPDATE disasters SET status='Expired',version=?,updated=? WHERE id=?").run(ver, now(), d.id); stats.notified += dispatch({ ...d, status: 'Expired', version: ver }); }
  return stats;
}
function activeFor(uid) { const loc = db.prepare('SELECT * FROM locations WHERE user_id=?').get(uid); if (!loc) return []; return db.prepare("SELECT * FROM disasters WHERE status='Active' ORDER BY issued DESC LIMIT 200").all().filter(d => usersInArea(d).includes(uid)).map(d => ({ id: d.id, type: d.type, severity: d.severity, level: d.level, title: d.title, area: d.area, source: d.source, url: d.url, safety: d.safety, issued: d.issued, expires: d.expires })); }
function status() { return { enabled: C.enabled, intervalMin: C.intervalMin, sources: db.prepare('SELECT source,ok,last_run lastRun,last_ok lastOk,error,items FROM source_health').all(), log: db.prepare('SELECT at,source,level,msg FROM monitor_log ORDER BY id DESC LIMIT 20').all() }; }
let timer; function start() { const go = () => runOnce().catch(e => log('monitor', 'error', e.message)); setTimeout(go, 3000).unref(); timer = setInterval(go, C.intervalMin * 60000); timer.unref(); }
module.exports = { start, runOnce, activeFor, status, usgs, rss };
