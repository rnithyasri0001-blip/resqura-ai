RESQURA AI prototype
Open index.html in Chrome/Edge/Safari. It works alone (app is embedded) - app.html is only an optional separate copy.
Flow: splash > role > login (GPS or manual location) > dashboard.
